package jp.citybuilder;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * /citybuilder reload | list [category] | info <id> | place <id> <pos> [rotation]
 *              | road <from> <to> [width] [style] | area <from> <to> <style>
 *              | undo | cancel | status | plan list | plan load <name> [origin]
 */
public final class CityCommands {
    private CityCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> build(dispatcher));
    }

    private static UUID ownerOf(class_2168 s) {
        return s.method_9228() instanceof class_3222 p ? p.method_5667() : CityActions.CONSOLE;
    }

    private static class_3222 playerOf(class_2168 s) {
        return s.method_9228() instanceof class_3222 p ? p : null;
    }

    private static int fail(class_2168 s, String msg) {
        s.method_9213(class_2561.method_43470(msg));
        return 0;
    }

    private static int ok(class_2168 s, String msg) {
        s.method_9226(class_2561.method_43470(msg), false);
        return 1;
    }

    private static int rotArg(int deg) {
        return deg >= 4 ? (deg / 90) & 3 : deg & 3;
    }

    private static void build(CommandDispatcher<class_2168> d) {
        LiteralArgumentBuilder<class_2168> root = class_2170.method_9247("citybuilder")
                .requires(PlacementValidator::canUse);

        root.then(class_2170.method_9247("reload").executes(ctx -> {
            CityBuilderMod.reload();
            ServerNet.broadcastCatalog(ctx.getSource().method_9211());
            return ok(ctx.getSource(), "再読み込みしました。建物数: " + CityBuilderMod.catalog().size());
        }));

        root.then(class_2170.method_9247("list")
                .executes(ctx -> list(ctx.getSource(), null))
                .then(class_2170.method_9244("category", StringArgumentType.greedyString())
                        .suggests((c, b) -> class_2172.method_9265(categories(), b))
                        .executes(ctx -> list(ctx.getSource(), StringArgumentType.getString(ctx, "category")))));

        root.then(class_2170.method_9247("info")
                .then(class_2170.method_9244("template", StringArgumentType.word())
                        .suggests((c, b) -> class_2172.method_9265(ids(), b))
                        .executes(ctx -> {
                            BuildingCatalog.Entry e = CityBuilderMod.catalog().get(StringArgumentType.getString(ctx, "template"));
                            if (e == null) return fail(ctx.getSource(), "不明なテンプレートです");
                            return ok(ctx.getSource(), e.id + " / " + e.name + " [" + e.category + "] "
                                    + e.size[0] + "x" + e.size[1] + "x" + e.size[2] + (e.floors > 0 ? " " + e.floors + "階" : "")
                                    + " " + e.description);
                        })));

        root.then(class_2170.method_9247("place")
                .then(class_2170.method_9244("template", StringArgumentType.word())
                        .suggests((c, b) -> class_2172.method_9265(ids(), b))
                        .then(class_2170.method_9244("pos", class_2262.method_9698())
                                .executes(ctx -> place(ctx, 0))
                                .then(class_2170.method_9244("rotation", IntegerArgumentType.integer(0, 360))
                                        .executes(ctx -> place(ctx, rotArg(IntegerArgumentType.getInteger(ctx, "rotation"))))))));

        root.then(class_2170.method_9247("road")
                .then(class_2170.method_9244("from", class_2262.method_9698())
                        .then(class_2170.method_9244("to", class_2262.method_9698())
                                .executes(ctx -> road(ctx, 7, "asphalt"))
                                .then(class_2170.method_9244("width", IntegerArgumentType.integer(3, 31))
                                        .executes(ctx -> road(ctx, IntegerArgumentType.getInteger(ctx, "width"), "asphalt"))
                                        .then(class_2170.method_9244("style", StringArgumentType.word())
                                                .suggests((c, b) -> class_2172.method_9265(jp.citybuilder.job.Styles.ROADS.keySet(), b))
                                                .executes(ctx -> road(ctx, IntegerArgumentType.getInteger(ctx, "width"),
                                                        StringArgumentType.getString(ctx, "style"))))))));

        root.then(class_2170.method_9247("area")
                .then(class_2170.method_9244("from", class_2262.method_9698())
                        .then(class_2170.method_9244("to", class_2262.method_9698())
                                .then(class_2170.method_9244("style", StringArgumentType.word())
                                        .suggests((c, b) -> class_2172.method_9265(jp.citybuilder.job.Styles.AREAS.keySet(), b))
                                        .executes(CityCommands::area)))));

        root.then(class_2170.method_9247("undo").executes(ctx -> {
            if (CityBuilderMod.jobs().undo(ownerOf(ctx.getSource()))) return ok(ctx.getSource(), "直前の作業を元に戻します");
            return fail(ctx.getSource(), "戻せる履歴がありません");
        }));

        root.then(class_2170.method_9247("cancel").executes(ctx -> {
            int n = CityBuilderMod.jobs().cancel(ownerOf(ctx.getSource()));
            return ok(ctx.getSource(), n + " 件の作業を取り消しました(途中までの変更は undo で戻せます)");
        }));

        root.then(class_2170.method_9247("status").executes(ctx -> ok(ctx.getSource(),
                "キュー: " + CityBuilderMod.jobs().queued() + " 件 / 残り約 " + CityBuilderMod.jobs().pending()
                        + " ブロック / あなたの履歴: " + CityBuilderMod.jobs().historySize(ownerOf(ctx.getSource())))));

        root.then(class_2170.method_9247("plan")
                .then(class_2170.method_9247("list").executes(ctx -> {
                    List<String> l = PlanLoader.list();
                    return ok(ctx.getSource(), l.isEmpty() ? "プランがありません (config/citybuilder/plans/*.json)" : "プラン: " + String.join(", ", l));
                }))
                .then(class_2170.method_9247("load")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                                .suggests((c, b) -> class_2172.method_9265(PlanLoader.list(), b))
                                .executes(ctx -> plan(ctx, null))
                                .then(class_2170.method_9244("origin", class_2262.method_9698())
                                        .executes(ctx -> plan(ctx, class_2262.method_9697(ctx, "origin")))))));

        d.register(root);
    }

    private static List<String> ids() {
        List<String> r = new ArrayList<>();
        for (BuildingCatalog.Entry e : CityBuilderMod.catalog().all()) r.add(e.id);
        return r;
    }

    private static Set<String> categories() {
        Set<String> r = new LinkedHashSet<>();
        for (BuildingCatalog.Entry e : CityBuilderMod.catalog().all()) r.add(e.category);
        return r;
    }

    private static int list(class_2168 s, String category) {
        StringBuilder sb = new StringBuilder();
        for (BuildingCatalog.Entry e : CityBuilderMod.catalog().all()) {
            if (category != null && !e.category.equals(category)) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(e.id);
        }
        if (sb.length() == 0) return fail(s, "該当する建物がありません。カテゴリ: " + String.join(", ", categories()));
        return ok(s, (category == null ? "全建物: " : category + ": ") + sb);
    }

    private static int place(CommandContext<class_2168> ctx, int rot) throws CommandSyntaxException {
        class_2168 s = ctx.getSource();
        class_2338 pos = class_2262.method_9697(ctx, "pos");
        String id = StringArgumentType.getString(ctx, "template");
        String err = CityActions.placeTemplate(s.method_9225(), playerOf(s), id, pos, rot);
        return err != null ? fail(s, err) : ok(s, "配置を開始: " + id + " @ " + pos.method_23854() + " 回転 " + rot * 90);
    }

    private static int road(CommandContext<class_2168> ctx, int width, String style) throws CommandSyntaxException {
        class_2168 s = ctx.getSource();
        class_2338 a = class_2262.method_9697(ctx, "from");
        class_2338 b = class_2262.method_9697(ctx, "to");
        String err = CityActions.road(s.method_9225(), playerOf(s), new int[]{a.method_10263(), b.method_10263()}, new int[]{a.method_10260(), b.method_10260()},
                a.method_10264(), width, true, style, "dashed");
        return err != null ? fail(s, err) : ok(s, "道路の作成を開始 (幅 " + width + ", " + style + ")");
    }

    private static int area(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 s = ctx.getSource();
        class_2338 a = class_2262.method_9697(ctx, "from");
        class_2338 b = class_2262.method_9697(ctx, "to");
        String style = StringArgumentType.getString(ctx, "style");
        String err = CityActions.area(s.method_9225(), playerOf(s), a.method_10263(), a.method_10260(), b.method_10263(), b.method_10260(), a.method_10264(), style);
        return err != null ? fail(s, err) : ok(s, "区画の作成を開始 (" + style + ")");
    }

    private static int plan(CommandContext<class_2168> ctx, class_2338 origin) {
        class_2168 s = ctx.getSource();
        class_3222 p = playerOf(s);
        if (origin == null) {
            if (p == null) return fail(s, "コンソールからは origin 座標を指定してください");
            origin = p.method_24515().method_10074(); // 立っているブロック(地表)
        }
        String name = StringArgumentType.getString(ctx, "name");
        try {
            PlanLoader.Result r = PlanLoader.load(s.method_9225(), p, name, origin);
            for (String e : r.errors) s.method_9213(class_2561.method_43470("  スキップ " + e));
            return ok(s, "プラン '" + name + "' を開始: " + r.accepted + " 件を受付 / " + r.skipped + " 件をスキップ (約 "
                    + r.estimate + " ブロック, 原点 " + origin.method_23854() + ")");
        } catch (IOException e) {
            return fail(s, e.getMessage());
        }
    }
}
