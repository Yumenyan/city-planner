package jp.citybuilder;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;

/**
 * Sponge Schematic (v2 / v3) の読み込み。
 * 原点は最小コーナー。回転0では正面が南(+Z)。
 * データ順は y→z→x。
 */
public final class Template {
    public final String id;
    public final int w, h, l;
    private final class_2680[] palette;
    private final int[] data;
    private final class_2680[][] rotCache = new class_2680[4][];

    private Template(String id, int w, int h, int l, class_2680[] palette, int[] data) {
        this.id = id; this.w = w; this.h = h; this.l = l; this.palette = palette; this.data = data;
    }

    public long volume() { return (long) w * h * l; }
    public int rw(int rot) { return (rot & 1) == 0 ? w : l; }
    public int rl(int rot) { return (rot & 1) == 0 ? l : w; }

    /** 回転後のパレット */
    public class_2680[] palette(int rot) {
        rot &= 3;
        class_2680[] r = rotCache[rot];
        if (r == null) {
            r = new class_2680[palette.length];
            class_2470 br = rot == 0 ? class_2470.field_11467
                    : rot == 1 ? class_2470.field_11463
                    : rot == 2 ? class_2470.field_11464
                    : class_2470.field_11465;
            for (int i = 0; i < r.length; i++) r[i] = palette[i].method_26186(br);
            rotCache[rot] = r;
        }
        return r;
    }

    public int paletteIndexAt(int idx) { return data[idx]; }

    /** 元座標(x,z)を回転後の相対座標へ(時計回り90度×rot)。結果は {nx, nz}。 */
    public void map(int x, int z, int rot, int[] out) {
        switch (rot & 3) {
            case 0: out[0] = x; out[1] = z; break;
            case 1: out[0] = l - 1 - z; out[1] = x; break;
            case 2: out[0] = w - 1 - x; out[1] = l - 1 - z; break;
            default: out[0] = z; out[1] = w - 1 - x; break;
        }
    }

    public static Template load(String id, Path file) throws IOException {
        class_2487 root;
        try (InputStream in = Files.newInputStream(file)) {
            root = class_2507.method_10629(in);
        }
        if (root.method_10573("Schematic", 10)) root = root.method_10562("Schematic");
        int w = root.method_10568("Width") & 0xFFFF;
        int h = root.method_10568("Height") & 0xFFFF;
        int l = root.method_10568("Length") & 0xFFFF;
        class_2487 pc;
        byte[] bytes;
        if (root.method_10573("Blocks", 10)) { // v3
            class_2487 b = root.method_10562("Blocks");
            pc = b.method_10562("Palette");
            bytes = b.method_10547("Data");
        } else { // v2
            pc = root.method_10562("Palette");
            bytes = root.method_10547("BlockData");
        }
        if (w <= 0 || h <= 0 || l <= 0) throw new IOException("サイズが不正です");
        int max = -1;
        for (String k : pc.method_10541()) max = Math.max(max, pc.method_10550(k));
        class_2680[] palette = new class_2680[max + 1];
        for (String k : pc.method_10541()) palette[pc.method_10550(k)] = parseState(k);
        for (int i = 0; i < palette.length; i++) if (palette[i] == null) palette[i] = class_2246.field_10124.method_9564();

        long total = (long) w * h * l;
        if (total > 50_000_000L) throw new IOException("テンプレートが大きすぎます");
        int[] data = new int[(int) total];
        int p = 0;
        for (int i = 0; i < data.length; i++) {
            int value = 0, shift = 0;
            while (true) {
                if (p >= bytes.length) throw new IOException("BlockData が途中で終わっています");
                int b = bytes[p++];
                value |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) break;
                shift += 7;
                if (shift > 28) throw new IOException("varint が不正です");
            }
            if (value >= palette.length) value = 0;
            data[i] = value;
        }
        return new Template(id, w, h, l, palette, data);
    }

    /** "minecraft:oak_stairs[facing=east,half=bottom]" 形式を BlockState にする。未知のブロックは空気。 */
    public static class_2680 parseState(String s) {
        String name = s;
        String props = null;
        int i = s.indexOf('[');
        if (i >= 0) {
            name = s.substring(0, i);
            int j = s.lastIndexOf(']');
            props = s.substring(i + 1, j > i ? j : s.length());
        }
        class_2960 rid = class_2960.method_12829(name);
        Optional<class_2248> ob = rid == null ? Optional.empty() : class_2378.field_11146.method_17966(rid);
        if (ob.isEmpty()) {
            CityBuilderMod.LOG.warn("未知のブロック: {}", s);
            return class_2246.field_10124.method_9564();
        }
        class_2680 st = ob.get().method_9564();
        if (props != null && !props.isEmpty()) {
            for (String kv : props.split(",")) {
                int eq = kv.indexOf('=');
                if (eq <= 0) continue;
                class_2769<?> prop = ob.get().method_9595().method_11663(kv.substring(0, eq).trim());
                if (prop != null) st = withProp(st, prop, kv.substring(eq + 1).trim());
            }
        }
        return st;
    }

    private static <T extends Comparable<T>> class_2680 withProp(class_2680 st, class_2769<T> prop, String v) {
        Optional<T> o = prop.method_11900(v);
        return o.isPresent() ? st.method_11657(prop, o.get()) : st;
    }
}
