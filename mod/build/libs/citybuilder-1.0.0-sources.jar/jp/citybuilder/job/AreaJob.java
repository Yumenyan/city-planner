package jp.citybuilder.job;

import java.util.UUID;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** 矩形区画(公園の芝生・広場・駐車場・水面など)。y が地表ブロックの高さ。 */
public final class AreaJob extends Job {
    private final int x1, z1, x2, z2, y, clearAbove, foundDepth;
    private final boolean foundation;
    private final class_2248 block;
    private int cx, cz;

    public AreaJob(UUID owner, class_3218 world, int x1, int z1, int x2, int z2, int y, class_2248 block,
                   int clearAbove, boolean foundation, int foundDepth) {
        super(owner, "area", world);
        this.x1 = Math.min(x1, x2); this.x2 = Math.max(x1, x2);
        this.z1 = Math.min(z1, z2); this.z2 = Math.max(z1, z2);
        this.y = y; this.block = block;
        this.clearAbove = clearAbove; this.foundation = foundation; this.foundDepth = foundDepth;
        cx = this.x1; cz = this.z1;
    }

    @Override
    public long estimate() { return (long) (x2 - x1 + 1) * (z2 - z1 + 1); }

    @Override
    public int step(int budget) {
        int used = 0;
        class_2680 state = block.method_9564();
        boolean water = block == class_2246.field_10382;
        while (used < budget) {
            if (cz > z2) { done = true; break; }
            used++;
            used += put(cx, y, cz, state);
            if (water) used += put(cx, y - 1, cz, class_2246.field_10102.method_9564());
            for (int d = 1; d <= clearAbove; d++) {
                if (!get(cx, y + d, cz).method_26215()) used += put(cx, y + d, cz, class_2246.field_10124.method_9564());
            }
            if (foundation && !water) used += foundation(cx, y, cz, foundDepth, class_2246.field_10340.method_9564());
            cx++;
            if (cx > x2) { cx = x1; cz++; }
        }
        if (cz > z2) done = true;
        return used;
    }
}
