package jp.citybuilder.job;

import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/** 履歴を逆順に適用して元に戻す(これ自体は履歴に残さない) */
public final class RestoreJob extends Job {
    private final UndoLog log;
    private int i;

    public RestoreJob(UUID owner, class_3218 world, UndoLog log, String label) {
        super(owner, label, world);
        this.log = log;
        this.i = log.n - 1;
    }

    @Override
    public long estimate() { return log.n; }

    @Override
    public int step(int budget) {
        int used = 0;
        class_2338.class_2339 m = new class_2338.class_2339();
        while (i >= 0 && used < budget) {
            m.method_16363(log.pos[i]);
            world.method_8652(m, log.st[i], FLAGS);
            i--;
            used++;
        }
        if (i < 0) done = true;
        return used;
    }
}
