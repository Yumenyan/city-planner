package jp.citybuilder.job;

import jp.citybuilder.Template;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import java.util.UUID;

/** 建物(.schem)を配置するジョブ。pos は回転後の最小コーナー。 */
public final class TemplateJob extends Job {
    private final Template t;
    private final class_2338 o;
    private final int rot;
    private final class_2680[] pal;
    private final boolean foundation;
    private final int foundDepth;
    private final int rw, rl;
    private final int total;
    private int fc;   // 基礎の列カウンタ
    private int idx;  // ブロックカウンタ
    private final int[] tmp = new int[2];

    public TemplateJob(UUID owner, class_3218 world, Template t, class_2338 origin, int rot,
                       boolean foundation, int foundDepth) {
        super(owner, t.id, world);
        this.t = t;
        this.o = origin;
        this.rot = rot & 3;
        this.pal = t.palette(this.rot);
        this.foundation = foundation;
        this.foundDepth = foundDepth;
        this.rw = t.rw(this.rot);
        this.rl = t.rl(this.rot);
        this.total = t.w * t.h * t.l;
    }

    @Override
    public long estimate() { return (long) total + (foundation ? (long) rw * rl : 0); }

    @Override
    public int step(int budget) {
        int used = 0;
        if (foundation) {
            int cols = rw * rl;
            while (fc < cols && used < budget) {
                int cx = fc % rw, cz = fc / rw;
                used += 1 + foundation(o.method_10263() + cx, o.method_10264(), o.method_10260() + cz, foundDepth, class_2246.field_10340.method_9564());
                fc++;
            }
            if (fc < cols) return used;
        }
        while (idx < total && used < budget) {
            int x = idx % t.w;
            int z = (idx / t.w) % t.l;
            int y = idx / (t.w * t.l);
            t.map(x, z, rot, tmp);
            put(o.method_10263() + tmp[0], o.method_10264() + y, o.method_10260() + tmp[1], pal[t.paletteIndexAt(idx)]);
            idx++;
            used++;
        }
        if (idx >= total) done = true;
        return used;
    }
}
