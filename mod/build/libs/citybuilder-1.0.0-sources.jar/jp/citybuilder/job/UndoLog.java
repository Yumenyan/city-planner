package jp.citybuilder.job;

import java.util.Arrays;
import net.minecraft.class_2680;

/** 変更前のブロックを記録して /citybuilder undo で戻すための履歴 */
public final class UndoLog {
    long[] pos = new long[1024];
    class_2680[] st = new class_2680[1024];
    int n;

    void add(long p, class_2680 s) {
        if (n == pos.length) {
            pos = Arrays.copyOf(pos, n * 2);
            st = Arrays.copyOf(st, n * 2);
        }
        pos[n] = p;
        st[n] = s;
        n++;
    }

    public int size() { return n; }
}
