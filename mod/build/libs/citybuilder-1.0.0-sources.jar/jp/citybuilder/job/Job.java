package jp.citybuilder.job;

import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** tickごとに予算ぶんだけ進める建築ジョブ */
public abstract class Job {
    /** 通知(ネイバー更新なし/形状更新なし)。NOTIFY_LISTENERS(2) | FORCE_STATE(16) */
    protected static final int FLAGS = 2 | 16;

    public final UUID owner;
    public final String label;
    public final class_3218 world;
    public UndoLog undo = new UndoLog();
    public boolean cancelled;
    public boolean done;
    public long placed;

    private final class_2338.class_2339 mut = new class_2338.class_2339();

    protected Job(UUID owner, String label, class_3218 world) {
        this.owner = owner;
        this.label = label;
        this.world = world;
    }

    /** 概算のブロック数(キュー管理用) */
    public abstract long estimate();

    /** budget までの作業量で進め、使った量を返す。完了したら done=true */
    public abstract int step(int budget);

    /** 1ブロック置く(履歴付き)。変化があれば1、なければ0 */
    protected int put(int x, int y, int z, class_2680 state) {
        mut.method_10103(x, y, z);
        class_2680 old = world.method_8320(mut);
        if (old == state) return 0;
        undo.add(mut.method_10063(), old);
        world.method_8652(mut, state, FLAGS);
        placed++;
        return 1;
    }

    protected class_2680 get(int x, int y, int z) {
        mut.method_10103(x, y, z);
        return world.method_8320(mut);
    }

    /** 柱の下の空洞(空気・水・草など)を fill で埋める。置いた数を返す */
    protected int foundation(int x, int y, int z, int depth, class_2680 fill) {
        int n = 0;
        for (int d = 1; d <= depth; d++) {
            class_2680 s = get(x, y - d, z);
            if (!s.method_26207().method_15800()) break;
            n += put(x, y - d, z, fill);
        }
        return n;
    }
}
