package jp.citybuilder.job;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;

/** 道路・区画のスタイル定義 */
public final class Styles {
    public static final class Road {
        public final class_2680 surface, sidewalk, white, yellow;
        Road(class_2248 surface, class_2248 sidewalk) {
            this.surface = surface.method_9564();
            this.sidewalk = sidewalk.method_9564();
            this.white = class_2246.field_10107.method_9564();
            this.yellow = class_2246.field_10542.method_9564();
        }
    }

    public static final Map<String, Road> ROADS = new LinkedHashMap<>();
    public static final Map<String, class_2248> AREAS = new LinkedHashMap<>();

    static {
        ROADS.put("asphalt", new Road(class_2246.field_10038, class_2246.field_10093));
        ROADS.put("concrete", new Road(class_2246.field_10172, class_2246.field_10360));
        ROADS.put("brick", new Road(class_2246.field_10104, class_2246.field_10056));
        ROADS.put("gravel", new Road(class_2246.field_10255, class_2246.field_10115));

        AREAS.put("grass", class_2246.field_10219);
        AREAS.put("plaza", class_2246.field_10360);
        AREAS.put("asphalt", class_2246.field_10038);
        AREAS.put("concrete", class_2246.field_10172);
        AREAS.put("sand", class_2246.field_10102);
        AREAS.put("dirt", class_2246.field_10253);
        AREAS.put("water", class_2246.field_10382);
    }

    public static Road road(String name) {
        return ROADS.get(name == null ? "asphalt" : name.toLowerCase());
    }

    /** 区画スタイル名またはブロックID。無効なら null */
    public static class_2248 area(String name) {
        if (name == null) return null;
        class_2248 b = AREAS.get(name.toLowerCase());
        if (b != null) return b;
        class_2960 id = class_2960.method_12829(name.contains(":") ? name : "minecraft:" + name);
        if (id == null) return null;
        return class_2378.field_11146.method_17966(id).filter(x -> x != class_2246.field_10124).orElse(null);
    }

    public static boolean isRoadBlock(class_2680 s) {
        class_2248 b = s.method_26204();
        for (Road r : ROADS.values()) {
            if (b == r.surface.method_26204() || b == r.white.method_26204() || b == r.yellow.method_26204()) return true;
        }
        return false;
    }
}
