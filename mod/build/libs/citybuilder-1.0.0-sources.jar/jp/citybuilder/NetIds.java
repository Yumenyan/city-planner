package jp.citybuilder;

import net.minecraft.class_2960;

/** 通信チャンネル。S2C: catalog / C2S: request_catalog, place, road, area, undo */
public final class NetIds {
    public static final class_2960 CATALOG = new class_2960("citybuilder", "catalog");
    public static final class_2960 REQUEST_CATALOG = new class_2960("citybuilder", "request_catalog");
    public static final class_2960 PLACE = new class_2960("citybuilder", "place");
    public static final class_2960 ROAD = new class_2960("citybuilder", "road");
    public static final class_2960 AREA = new class_2960("citybuilder", "area");
    public static final class_2960 UNDO = new class_2960("citybuilder", "undo");

    private NetIds() {}
}
