package jp.citybuilder;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.nio.charset.StandardCharsets;

/** クライアント⇔サーバーの通信。クライアントには建物IDと寸法などのカタログ情報だけを送る。 */
public final class ServerNet {
    private ServerNet() {}

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(NetIds.REQUEST_CATALOG, (server, player, handler, buf, sender) ->
                server.execute(() -> sendCatalog(player)));

        ServerPlayNetworking.registerGlobalReceiver(NetIds.UNDO, (server, player, handler, buf, sender) ->
                server.execute(() -> CityActions.onUndo(player)));

        ServerPlayNetworking.registerGlobalReceiver(NetIds.PLACE, (server, player, handler, buf, sender) -> {
            try {
                String id = buf.method_10800(64);
                class_2338 pos = buf.method_10811();
                int rot = buf.readByte();
                server.execute(() -> CityActions.onPlace(player, id, pos, rot));
            } catch (RuntimeException e) {
                CityBuilderMod.LOG.warn("不正な place パケット: {}", e.toString());
            }
        });

        ServerPlayNetworking.registerGlobalReceiver(NetIds.ROAD, (server, player, handler, buf, sender) -> {
            try {
                int width = buf.method_10816();
                boolean sidewalk = buf.readBoolean();
                String style = buf.method_10800(32);
                String lines = buf.method_10800(16);
                int n = buf.method_10816();
                if (n < 2 || n > 256) return;
                int[] px = new int[n], pz = new int[n];
                int y = 0;
                for (int i = 0; i < n; i++) {
                    class_2338 p = buf.method_10811();
                    px[i] = p.method_10263(); pz[i] = p.method_10260();
                    if (i == 0) y = p.method_10264();
                }
                final int fy = y;
                server.execute(() -> CityActions.onRoad(player, px, pz, fy, width, sidewalk, style, lines));
            } catch (RuntimeException e) {
                CityBuilderMod.LOG.warn("不正な road パケット: {}", e.toString());
            }
        });

        ServerPlayNetworking.registerGlobalReceiver(NetIds.AREA, (server, player, handler, buf, sender) -> {
            try {
                class_2338 a = buf.method_10811();
                class_2338 b = buf.method_10811();
                String style = buf.method_10800(48);
                server.execute(() -> CityActions.onArea(player, a.method_10263(), a.method_10260(), b.method_10263(), b.method_10260(), a.method_10264(), style));
            } catch (RuntimeException e) {
                CityBuilderMod.LOG.warn("不正な area パケット: {}", e.toString());
            }
        });
    }

    public static void sendCatalog(class_3222 p) {
        CityConfig c = CityBuilderMod.config();
        String json = CityBuilderMod.catalog().toClientJson(PlacementValidator.canUse(p), c.maxPlaceDistance);
        class_2540 buf = PacketByteBufs.create();
        buf.method_10813(json.getBytes(StandardCharsets.UTF_8));
        ServerPlayNetworking.send(p, NetIds.CATALOG, buf);
    }

    public static void broadcastCatalog(MinecraftServer server) {
        for (class_3222 p : server.method_3760().method_14571()) sendCatalog(p);
    }
}
