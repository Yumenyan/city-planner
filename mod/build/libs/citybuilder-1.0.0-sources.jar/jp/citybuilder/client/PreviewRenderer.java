package jp.citybuilder.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1159;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4581;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import java.util.ArrayList;
import java.util.List;

/**
 * 配置プレビュー。クライアントは建物のブロックデータを持たないので、
 * 半透明の占有ボリューム + ワイヤーフレーム + 1段目の床面 + 正面マーカーで表現する。
 */
public final class PreviewRenderer {
    private PreviewRenderer() {}

    public static void register() {
        WorldRenderEvents.LAST.register(PreviewRenderer::render);
    }

    private static final class Box {
        final double x1, y1, z1, x2, y2, z2;
        final float r, g, b, fill;
        Box(double x1, double y1, double z1, double x2, double y2, double z2, float r, float g, float b, float fill) {
            this.x1 = x1; this.y1 = y1; this.z1 = z1; this.x2 = x2; this.y2 = y2; this.z2 = z2;
            this.r = r; this.g = g; this.b = b; this.fill = fill;
        }
    }

    private static final class Line {
        final double x1, y1, z1, x2, y2, z2;
        final float r, g, b;
        Line(double x1, double y1, double z1, double x2, double y2, double z2, float r, float g, float b) {
            this.x1 = x1; this.y1 = y1; this.z1 = z1; this.x2 = x2; this.y2 = y2; this.z2 = z2;
            this.r = r; this.g = g; this.b = b;
        }
    }

    private static void render(WorldRenderContext ctx) {
        if (!PlacementMode.active()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        boolean ok = ClientCatalog.canBuild;
        float cr = ok ? 0.2f : 1.0f, cg = ok ? 0.9f : 0.2f, cb = ok ? 0.4f : 0.2f;

        List<Box> boxes = new ArrayList<>();
        List<Line> lines = new ArrayList<>();
        class_2338 t = PlacementMode.target;

        switch (PlacementMode.kind) {
            case BUILDING: {
                class_2338 o = PlacementMode.origin();
                if (o == null) return;
                int w = PlacementMode.rw(), l = PlacementMode.rl(), h = PlacementMode.entry.h;
                boxes.add(new Box(o.method_10263(), o.method_10264(), o.method_10260(), o.method_10263() + w, o.method_10264() + h, o.method_10260() + l, cr, cg, cb, 0.12f));
                boxes.add(new Box(o.method_10263(), o.method_10264(), o.method_10260(), o.method_10263() + w, o.method_10264() + 1, o.method_10260() + l, 1f, 1f, 0.3f, 0.25f));
                // 正面(回転0=南)。時計回りに rot 回転: 南→西→北→東
                int fdx = 0, fdz = 1;
                switch (PlacementMode.rot & 3) {
                    case 1: fdx = -1; fdz = 0; break;
                    case 2: fdx = 0; fdz = -1; break;
                    case 3: fdx = 1; fdz = 0; break;
                    default:
                }
                double cx = o.method_10263() + w / 2.0, cz = o.method_10260() + l / 2.0, y = o.method_10264() + 1.02;
                double ex = cx + fdx * (w / 2.0), ez = cz + fdz * (l / 2.0);      // 正面の辺の中央
                double tx = ex + fdx * 4, tz = ez + fdz * 4;                        // 矢印の先
                lines.add(new Line(cx, y, cz, tx, y, tz, 1f, 0.9f, 0.1f));
                lines.add(new Line(tx, y, tz, tx - fdx * 1.5 - fdz * 1.5, y, tz - fdz * 1.5 + fdx * 1.5, 1f, 0.9f, 0.1f));
                lines.add(new Line(tx, y, tz, tx - fdx * 1.5 + fdz * 1.5, y, tz - fdz * 1.5 - fdx * 1.5, 1f, 0.9f, 0.1f));
                break;
            }
            case ROAD: {
                List<class_2338> pts = PlacementMode.points;
                double hw = PlacementMode.roadWidth / 2.0;
                for (class_2338 p : pts) {
                    boxes.add(new Box(p.method_10263() + 0.5 - hw, p.method_10264(), p.method_10260() + 0.5 - hw, p.method_10263() + 0.5 + hw, p.method_10264() + 1, p.method_10260() + 0.5 + hw, 0.9f, 0.9f, 0.9f, 0.10f));
                }
                for (int i = 0; i + 1 < pts.size(); i++) {
                    class_2338 a = pts.get(i), b = pts.get(i + 1);
                    lines.add(new Line(a.method_10263() + 0.5, a.method_10264() + 1.05, a.method_10260() + 0.5, b.method_10263() + 0.5, a.method_10264() + 1.05, b.method_10260() + 0.5, 1f, 1f, 1f));
                }
                if (t != null) {
                    double y = pts.isEmpty() ? t.method_10264() : pts.get(0).method_10264();
                    boxes.add(new Box(t.method_10263() + 0.5 - hw, y, t.method_10260() + 0.5 - hw, t.method_10263() + 0.5 + hw, y + 1, t.method_10260() + 0.5 + hw, cr, cg, cb, 0.18f));
                    if (!pts.isEmpty()) {
                        class_2338 a = pts.get(pts.size() - 1);
                        lines.add(new Line(a.method_10263() + 0.5, y + 1.05, a.method_10260() + 0.5, t.method_10263() + 0.5, y + 1.05, t.method_10260() + 0.5, cr, cg, cb));
                    }
                }
                break;
            }
            case AREA: {
                class_2338 a = PlacementMode.areaFirst;
                if (a != null && t != null) {
                    int x1 = Math.min(a.method_10263(), t.method_10263()), x2 = Math.max(a.method_10263(), t.method_10263());
                    int z1 = Math.min(a.method_10260(), t.method_10260()), z2 = Math.max(a.method_10260(), t.method_10260());
                    boxes.add(new Box(x1, a.method_10264(), z1, x2 + 1, a.method_10264() + 1, z2 + 1, cr, cg, cb, 0.25f));
                } else if (t != null) {
                    boxes.add(new Box(t.method_10263(), t.method_10264(), t.method_10260(), t.method_10263() + 1, t.method_10264() + 1, t.method_10260() + 1, cr, cg, cb, 0.3f));
                }
                break;
            }
            default:
                return;
        }

        class_4587 ms = ctx.matrixStack();
        class_243 cam = ctx.camera().method_19326();
        ms.method_22903();
        ms.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);
        class_1159 pos = ms.method_23760().method_23761();
        class_4581 nrm = ms.method_23760().method_23762();

        // この時点でRenderSystem側のモデルビューにカメラ回転が残っていると二重に回転して傾いて見える。
        // 頂点は上で変換済みなので、描画中だけ単位行列にする。
        class_4587 mv = RenderSystem.getModelViewStack();
        mv.method_22903();
        mv.method_23760().method_23761().method_22668();
        mv.method_23760().method_23762().method_22856();
        RenderSystem.applyModelViewMatrix();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();

        // 半透明の面
        RenderSystem.depthMask(false);
        RenderSystem.setShader(class_757::method_34540);
        class_289 tess = class_289.method_1348();
        class_287 bb = tess.method_1349();
        bb.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
        for (Box b : boxes) fillBox(bb, pos, b);
        tess.method_1350();
        RenderSystem.depthMask(true);

        // 線: 地形に隠れる部分は薄く、見える部分は濃く
        RenderSystem.setShader(class_757::method_34535);
        RenderSystem.lineWidth(3.0f);
        RenderSystem.disableDepthTest();
        drawLines(tess, pos, nrm, boxes, lines, 0.35f);
        RenderSystem.enableDepthTest();
        drawLines(tess, pos, nrm, boxes, lines, 1.0f);

        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        mv.method_22909();
        RenderSystem.applyModelViewMatrix();
        ms.method_22909();
    }

    private static void drawLines(class_289 tess, class_1159 pos, class_4581 nrm, List<Box> boxes, List<Line> lines, float alpha) {
        class_287 bb = tess.method_1349();
        bb.method_1328(class_293.class_5596.field_27377, class_290.field_29337);
        for (Box b : boxes) {
            float a = alpha * (b.fill >= 0.2f ? 0.8f : 1.0f);
            double[] xs = {b.x1, b.x2}, ys = {b.y1, b.y2}, zs = {b.z1, b.z2};
            for (int i = 0; i < 2; i++) for (int j = 0; j < 2; j++) {
                line(bb, pos, nrm, xs[0], ys[i], zs[j], xs[1], ys[i], zs[j], b.r, b.g, b.b, a);
                line(bb, pos, nrm, xs[i], ys[0], zs[j], xs[i], ys[1], zs[j], b.r, b.g, b.b, a);
                line(bb, pos, nrm, xs[i], ys[j], zs[0], xs[i], ys[j], zs[1], b.r, b.g, b.b, a);
            }
        }
        for (Line l : lines) line(bb, pos, nrm, l.x1, l.y1, l.z1, l.x2, l.y2, l.z2, l.r, l.g, l.b, alpha);
        tess.method_1350();
    }

    private static void line(class_287 bb, class_1159 pos, class_4581 nrm,
                             double x1, double y1, double z1, double x2, double y2, double z2,
                             float r, float g, float b, float a) {
        float nx = (float) (x2 - x1), ny = (float) (y2 - y1), nz = (float) (z2 - z1);
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1e-6f) return;
        nx /= len; ny /= len; nz /= len;
        bb.method_22918(pos, (float) x1, (float) y1, (float) z1).method_22915(r, g, b, a).method_23763(nrm, nx, ny, nz).method_1344();
        bb.method_22918(pos, (float) x2, (float) y2, (float) z2).method_22915(r, g, b, a).method_23763(nrm, nx, ny, nz).method_1344();
    }

    private static void quad(class_287 bb, class_1159 m, float r, float g, float b, float a,
                             double ax, double ay, double az, double bx, double by, double bz,
                             double cx, double cy, double cz, double dx, double dy, double dz) {
        bb.method_22918(m, (float) ax, (float) ay, (float) az).method_22915(r, g, b, a).method_1344();
        bb.method_22918(m, (float) bx, (float) by, (float) bz).method_22915(r, g, b, a).method_1344();
        bb.method_22918(m, (float) cx, (float) cy, (float) cz).method_22915(r, g, b, a).method_1344();
        bb.method_22918(m, (float) dx, (float) dy, (float) dz).method_22915(r, g, b, a).method_1344();
    }

    private static void fillBox(class_287 bb, class_1159 m, Box b) {
        float r = b.r, g = b.g, bl = b.b, a = b.fill;
        double x1 = b.x1, y1 = b.y1, z1 = b.z1, x2 = b.x2, y2 = b.y2, z2 = b.z2;
        quad(bb, m, r, g, bl, a, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2); // 下
        quad(bb, m, r, g, bl, a, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1); // 上
        quad(bb, m, r, g, bl, a, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1); // 北
        quad(bb, m, r, g, bl, a, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2); // 南
        quad(bb, m, r, g, bl, a, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1); // 西
        quad(bb, m, r, g, bl, a, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2); // 東
    }
}
