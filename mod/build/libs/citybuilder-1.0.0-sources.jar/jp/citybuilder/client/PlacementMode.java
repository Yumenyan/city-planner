package jp.citybuilder.client;

import jp.citybuilder.NetIds;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;

/** 配置モード(建物 / 道路 / 区画)の状態。見ている地表ブロックを基準に、プレビューを追従させる。 */
public final class PlacementMode {
    public enum Kind { NONE, BUILDING, ROAD, AREA }

    public static Kind kind = Kind.NONE;
    public static ClientCatalog.Entry entry;
    public static int rot, dx, dy, dz;
    public static class_2338 target;

    public static int roadWidth = 7;
    public static String roadStyle = "asphalt";
    public static String lines = "dashed";
    public static final List<class_2338> points = new ArrayList<>();

    public static String areaStyle = "grass";
    public static class_2338 areaFirst;

    private PlacementMode() {}

    public static boolean active() { return kind != Kind.NONE; }

    public static void startBuilding(ClientCatalog.Entry e) {
        kind = Kind.BUILDING; entry = e; rot = 0; dx = dy = dz = 0; target = null;
    }

    public static void startRoad() {
        kind = Kind.ROAD; points.clear(); target = null;
    }

    public static void startArea() {
        kind = Kind.AREA; areaFirst = null; target = null;
    }

    public static void cancel() {
        kind = Kind.NONE; entry = null; points.clear(); areaFirst = null; target = null;
    }

    public static int rw() { return entry == null ? 1 : ((rot & 1) == 0 ? entry.w : entry.l); }
    public static int rl() { return entry == null ? 1 : ((rot & 1) == 0 ? entry.l : entry.w); }

    /** 建物の最小コーナー(サーバーに送る位置) */
    public static class_2338 origin() {
        if (target == null) return null;
        return new class_2338(target.method_10263() - rw() / 2 + dx, target.method_10264() + dy, target.method_10260() - rl() / 2 + dz);
    }

    public static void rotate() { rot = (rot + 1) & 3; }
    public static void nudge(int x, int y, int z) { dx += x; dy += y; dz += z; }

    public static void tick(class_310 mc) {
        if (!active() || mc.field_1724 == null) return;
        class_239 hit = mc.field_1724.method_5745(ClientCatalog.maxDistance, 1.0f, false);
        if (hit.method_17783() == class_239.class_240.field_1332) target = ((class_3965) hit).method_17777();
        else target = null;
    }

    /**
     * クライアントtick開始時に呼ぶ。配置モード中は攻撃/使用キーの押下をここで消費して、
     * バニラのブロック破壊・設置を起こさせず、左クリック=確定 / 右クリック=終了 として扱う。
     */
    public static void input(class_310 mc) {
        if (!active() || mc.field_1724 == null || mc.field_1755 != null) return;
        // 左クリックはブロック破壊を防ぐために消費するだけ
        while (mc.field_1690.field_1886.method_1436()) { /* 何もしない */ }
        // 右クリック=選択/指定、Shift+右クリック=取り消し
        while (mc.field_1690.field_1904.method_1436()) {
            if (!active()) break;
            if (class_437.method_25442()) cancelStep(mc);
            else confirm(mc);
        }
        mc.field_1690.field_1886.method_23481(false);
        mc.field_1690.field_1904.method_23481(false);
    }

    private static void msg(class_310 mc, String s) {
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470("[CityBuilder] " + s), true);
    }

    private static void confirm(class_310 mc) {
        if (!ClientCatalog.canBuild) { msg(mc, "このサーバーでは建築する権限がありません"); return; }
        if (target == null) { msg(mc, "地面を見てください"); return; }
        switch (kind) {
            case BUILDING: {
                class_2338 o = origin();
                class_2540 buf = PacketByteBufs.create();
                buf.method_10788(entry.id, 64);
                buf.method_10807(o);
                buf.writeByte(rot);
                ClientPlayNetworking.send(NetIds.PLACE, buf);
                break;
            }
            case ROAD: {
                class_2338 last = points.isEmpty() ? null : points.get(points.size() - 1);
                if (last != null && last.method_10263() == target.method_10263() && last.method_10260() == target.method_10260()) {
                    sendRoad(); // 同じ点をもう一度指定 = 確定
                } else if (points.size() < 256) {
                    points.add(target);
                }
                break;
            }
            case AREA:
                if (areaFirst == null) {
                    areaFirst = target;
                } else {
                    class_2540 buf = PacketByteBufs.create();
                    buf.method_10807(areaFirst);
                    buf.method_10807(new class_2338(target.method_10263(), areaFirst.method_10264(), target.method_10260()));
                    buf.method_10788(areaStyle, 48);
                    ClientPlayNetworking.send(NetIds.AREA, buf);
                    areaFirst = null;
                }
                break;
            default:
        }
    }

    private static void sendRoad() {
        if (points.size() < 2) { points.clear(); return; }
        class_2540 buf = PacketByteBufs.create();
        buf.method_10804(roadWidth);
        buf.writeBoolean(true);
        buf.method_10788(roadStyle, 32);
        buf.method_10788(lines, 16);
        buf.method_10804(points.size());
        int y = points.get(0).method_10264();
        for (class_2338 p : points) buf.method_10807(new class_2338(p.method_10263(), y, p.method_10260()));
        ClientPlayNetworking.send(NetIds.ROAD, buf);
        points.clear();
    }

    /** Shift+右クリック: 1手戻す。戻すものが無ければ配置モードを終了 */
    private static void cancelStep(class_310 mc) {
        switch (kind) {
            case ROAD:
                if (!points.isEmpty()) points.remove(points.size() - 1);
                else cancel();
                break;
            case AREA:
                if (areaFirst != null) areaFirst = null;
                else cancel();
                break;
            default:
                cancel();
        }
    }
}
