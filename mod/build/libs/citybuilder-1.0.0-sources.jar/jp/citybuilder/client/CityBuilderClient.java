package jp.citybuilder.client;

import jp.citybuilder.NetIds;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import org.lwjgl.glfw.GLFW;

import java.nio.charset.StandardCharsets;

public final class CityBuilderClient implements ClientModInitializer {
    private static final String CAT = "key.categories.citybuilder";
    private static class_304 open, rotate, north, south, west, east, up, down;

    private static class_304 key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new class_304("key.citybuilder." + name, class_3675.class_307.field_1668, code, CAT));
    }

    @Override
    public void onInitializeClient() {
        open = key("open", GLFW.GLFW_KEY_B);
        rotate = key("rotate", GLFW.GLFW_KEY_R);
        north = key("nudge_north", GLFW.GLFW_KEY_UP);
        south = key("nudge_south", GLFW.GLFW_KEY_DOWN);
        west = key("nudge_west", GLFW.GLFW_KEY_LEFT);
        east = key("nudge_east", GLFW.GLFW_KEY_RIGHT);
        up = key("nudge_up", GLFW.GLFW_KEY_PAGE_UP);
        down = key("nudge_down", GLFW.GLFW_KEY_PAGE_DOWN);

        ClientPlayNetworking.registerGlobalReceiver(NetIds.CATALOG, (client, handler, buf, sender) -> {
            byte[] bytes = buf.method_10795();
            client.execute(() -> ClientCatalog.update(new String(bytes, StandardCharsets.UTF_8)));
        });

        ClientTickEvents.END_CLIENT_TICK.register(CityBuilderClient::tick);

        // 配置モード中の左/右クリックは tick 開始時に消費して処理する(バニラの破壊・設置を防ぐ)
        ClientTickEvents.START_CLIENT_TICK.register(PlacementMode::input);

        HudRenderCallback.EVENT.register(CityBuilderClient::hud);
        PreviewRenderer.register();
    }

    private static void tick(class_310 mc) {
        boolean noScreen = mc.field_1755 == null;
        while (open.method_1436()) {
            if (noScreen && mc.field_1724 != null) {
                mc.method_1507(new CityBuilderScreen());
                noScreen = false;
            }
        }
        boolean building = PlacementMode.kind == PlacementMode.Kind.BUILDING;
        while (rotate.method_1436()) if (building && noScreen) PlacementMode.rotate();
        while (north.method_1436()) if (building && noScreen) PlacementMode.nudge(0, 0, -1);
        while (south.method_1436()) if (building && noScreen) PlacementMode.nudge(0, 0, 1);
        while (west.method_1436()) if (building && noScreen) PlacementMode.nudge(-1, 0, 0);
        while (east.method_1436()) if (building && noScreen) PlacementMode.nudge(1, 0, 0);
        while (up.method_1436()) if (building && noScreen) PlacementMode.nudge(0, 1, 0);
        while (down.method_1436()) if (building && noScreen) PlacementMode.nudge(0, -1, 0);
        PlacementMode.tick(mc);
    }

    private static void hud(class_4587 m, float tickDelta) {
        if (!PlacementMode.active()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null) return;
        int x = 8, y = 8;
        String head;
        String help;
        switch (PlacementMode.kind) {
            case BUILDING: {
                class_2338 o = PlacementMode.origin();
                head = "§e建物: §f" + PlacementMode.entry.name + "  §7(" + PlacementMode.rw() + "×" + PlacementMode.entry.h + "×" + PlacementMode.rl()
                        + ")  回転 " + (PlacementMode.rot * 90) + "°" + (o == null ? "" : "  @ " + o.method_10263() + ", " + o.method_10264() + ", " + o.method_10260());
                help = "右クリック:ここに建てる  Shift+右クリック:やめる  R:回転  矢印:移動  PgUp/PgDn:上下";
                break;
            }
            case ROAD:
                head = "§e道路ツール §7幅 " + PlacementMode.roadWidth + " / " + PlacementMode.roadStyle + " / 点 " + PlacementMode.points.size();
                help = "右クリック:点を追加(同じ点をもう一度で確定)  Shift+右クリック:1点戻す/終了";
                break;
            default:
                head = "§e区画ツール §7" + PlacementMode.areaStyle + (PlacementMode.areaFirst == null ? "" : "  (角を指定済み)");
                help = "右クリック:角を指定→反対の角で確定  Shift+右クリック:取り消し";
        }
        mc.field_1772.method_30881(m, class_2561.method_43470(head), x, y, 0xFFFFFF);
        mc.field_1772.method_30881(m, class_2561.method_43470(help), x, y + 12, 0xCCCCCC);
        if (!ClientCatalog.canBuild) {
            mc.field_1772.method_30881(m, class_2561.method_43470("§c建築権限がありません"), x, y + 24, 0xFF5555);
        } else if (PlacementMode.target == null) {
            mc.field_1772.method_30881(m, class_2561.method_43470("§7地面を見てください"), x, y + 24, 0xAAAAAA);
        }
    }
}
