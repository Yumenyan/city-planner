package jp.citybuilder.client;

import jp.citybuilder.NetIds;
import jp.citybuilder.job.Styles;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import java.util.ArrayList;
import java.util.List;

/** City Builder のメニュー。建物 / 道路 / 区画 の3タブ。 */
public final class CityBuilderScreen extends class_437 {
    private static final String[] LINES = {"none", "dashed", "solid", "double"};
    private static final String[] LINE_JA = {"なし", "破線", "実線", "二重線"};
    private static final int[] WIDTHS = {3, 5, 7, 9, 11, 13, 15};

    private static int tab = 0;
    private static int catIdx = 0;
    private static int page = 0;

    private final List<ClientCatalog.Entry> shown = new ArrayList<>();
    private final List<int[]> rects = new ArrayList<>();
    private int hovered = -1;

    public CityBuilderScreen() {
        super(class_2561.method_43470("City Builder"));
    }

    @Override
    public boolean method_25421() { return false; }

    private void tabButton(int x, String label, int idx) {
        class_4185 b = new class_4185(x, 22, 60, 20, class_2561.method_43470((tab == idx ? "▶ " : "") + label), btn -> {
            tab = idx;
            page = 0;
            rebuild();
        });
        method_37063(b);
    }

    private void rebuild() {
        method_37067();
        method_25426();
    }

    @Override
    protected void method_25426() {
        shown.clear();
        rects.clear();
        int left = 10;
        tabButton(left, "建物", 0);
        tabButton(left + 64, "道路", 1);
        tabButton(left + 128, "区画", 2);

        method_37063(new class_4185(field_22789 - 110, 22, 100, 20, class_2561.method_43470("元に戻す(undo)"), b ->
                ClientPlayNetworking.send(NetIds.UNDO, PacketByteBufs.create())));
        method_37063(new class_4185(field_22789 - 220, 22, 100, 20, class_2561.method_43470("カタログ更新"), b ->
                ClientPlayNetworking.send(NetIds.REQUEST_CATALOG, PacketByteBufs.create())));

        if (tab == 0) initBuildings();
        else if (tab == 1) initRoad();
        else initArea();
    }

    private void initBuildings() {
        List<String> cats = ClientCatalog.categories();
        if (cats.isEmpty()) return;
        if (catIdx >= cats.size()) catIdx = 0;
        int y = 50;
        for (int i = 0; i < cats.size(); i++) {
            final int idx = i;
            String label = (i == catIdx ? "▶ " : "") + cats.get(i);
            method_37063(new class_4185(10, y, 110, 20, class_2561.method_43470(label), b -> {
                catIdx = idx;
                page = 0;
                rebuild();
            }));
            y += 22;
        }
        List<ClientCatalog.Entry> list = ClientCatalog.inCategory(cats.get(catIdx));
        int perPage = Math.max(3, (field_22790 - 50 - 40) / 22);
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;
        int from = page * perPage;
        int ly = 50;
        for (int i = from; i < Math.min(list.size(), from + perPage); i++) {
            ClientCatalog.Entry e = list.get(i);
            shown.add(e);
            rects.add(new int[]{130, ly, 250, 20});
            String label = e.name + "  (" + e.w + "×" + e.l + ")";
            method_37063(new class_4185(130, ly, 250, 20, class_2561.method_43470(label), b -> {
                PlacementMode.startBuilding(e);
                method_25419();
            }));
            ly += 22;
        }
        if (pages > 1) {
            int py = field_22790 - 28;
            method_37063(new class_4185(130, py, 40, 20, class_2561.method_43470("◀"), b -> { if (page > 0) { page--; rebuild(); } }));
            method_37063(new class_4185(340, py, 40, 20, class_2561.method_43470("▶"), b -> { if (page < pages - 1) { page++; rebuild(); } }));
        }
    }

    private static <T> int indexOf(T[] arr, T v) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(v)) return i;
        return 0;
    }

    private void initRoad() {
        int x = 130, y = 60;
        method_37063(new class_4185(x, y, 250, 20, class_2561.method_43470("幅: " + PlacementMode.roadWidth), b -> {
            int i = 0;
            for (int k = 0; k < WIDTHS.length; k++) if (WIDTHS[k] == PlacementMode.roadWidth) i = k;
            PlacementMode.roadWidth = WIDTHS[(i + 1) % WIDTHS.length];
            b.method_25355(class_2561.method_43470("幅: " + PlacementMode.roadWidth));
        }));
        y += 26;
        List<String> styles = new ArrayList<>(Styles.ROADS.keySet());
        method_37063(new class_4185(x, y, 250, 20, class_2561.method_43470("路面: " + PlacementMode.roadStyle), b -> {
            int i = Math.max(0, styles.indexOf(PlacementMode.roadStyle));
            PlacementMode.roadStyle = styles.get((i + 1) % styles.size());
            b.method_25355(class_2561.method_43470("路面: " + PlacementMode.roadStyle));
        }));
        y += 26;
        method_37063(new class_4185(x, y, 250, 20, class_2561.method_43470("中央線: " + LINE_JA[indexOf(LINES, PlacementMode.lines)]), b -> {
            int i = indexOf(LINES, PlacementMode.lines);
            PlacementMode.lines = LINES[(i + 1) % LINES.length];
            b.method_25355(class_2561.method_43470("中央線: " + LINE_JA[indexOf(LINES, PlacementMode.lines)]));
        }));
        y += 34;
        method_37063(new class_4185(x, y, 250, 20, class_2561.method_43470("道路ツールを開始"), b -> {
            PlacementMode.startRoad();
            method_25419();
        }));
    }

    private void initArea() {
        int x = 130, y = 60;
        List<String> styles = new ArrayList<>(Styles.AREAS.keySet());
        method_37063(new class_4185(x, y, 250, 20, class_2561.method_43470("種類: " + PlacementMode.areaStyle), b -> {
            int i = Math.max(0, styles.indexOf(PlacementMode.areaStyle));
            PlacementMode.areaStyle = styles.get((i + 1) % styles.size());
            b.method_25355(class_2561.method_43470("種類: " + PlacementMode.areaStyle));
        }));
        y += 34;
        method_37063(new class_4185(x, y, 250, 20, class_2561.method_43470("区画ツールを開始"), b -> {
            PlacementMode.startArea();
            method_25419();
        }));
    }

    @Override
    public void method_25394(class_4587 m, int mx, int my, float delta) {
        method_25420(m);
        method_27534(m, field_22793, class_2561.method_43470("City Builder"), field_22789 / 2, 8, 0xFFFFFF);
        super.method_25394(m, mx, my, delta);

        if (!ClientCatalog.canBuild) {
            method_27534(m, field_22793, class_2561.method_43470("§cこのサーバーでは建築権限がありません"), field_22789 / 2, field_22790 - 12, 0xFF5555);
        }
        if (tab == 0) {
            if (ClientCatalog.categories().isEmpty()) {
                field_22793.method_30883(m, class_2561.method_43470("建物カタログを受信していません。「カタログ更新」を押してください。"), 130, 60, 0xFFAA00);
            }
            hovered = -1;
            for (int i = 0; i < rects.size(); i++) {
                int[] r = rects.get(i);
                if (mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3]) hovered = i;
            }
            if (hovered >= 0) {
                ClientCatalog.Entry e = shown.get(hovered);
                int x = 395, y = 56;
                field_22793.method_30883(m, class_2561.method_43470("§e" + e.name), x, y, 0xFFFFFF); y += 12;
                field_22793.method_30883(m, class_2561.method_43470("ID: " + e.id), x, y, 0xAAAAAA); y += 12;
                field_22793.method_30883(m, class_2561.method_43470("寸法: " + e.w + " × " + e.h + " × " + e.l + " (幅×高さ×奥行)"), x, y, 0xFFFFFF); y += 12;
                if (e.floors > 0) { field_22793.method_30883(m, class_2561.method_43470("階数: " + e.floors), x, y, 0xFFFFFF); y += 12; }
                int maxW = Math.max(80, field_22789 - x - 10);
                for (var line : field_22793.method_1728(class_2561.method_43470(e.description), maxW)) {
                    field_22793.method_27528(m, line, x, y, 0xCCCCCC);
                    y += 11;
                }
            }
        } else if (tab == 1) {
            field_22793.method_30883(m, class_2561.method_43470("右クリック: 点を追加 / 同じ点をもう一度右クリック: 確定(2点以上)"), 130, 190, 0xCCCCCC);
            field_22793.method_30883(m, class_2561.method_43470("道路幅は奇数が左右対称になります。歩道(幅2)は自動で付きます。"), 130, 202, 0xAAAAAA);
        } else {
            field_22793.method_30883(m, class_2561.method_43470("1回目の右クリック: 角を指定 / 2回目: 反対の角で確定"), 130, 150, 0xCCCCCC);
            field_22793.method_30883(m, class_2561.method_43470("Shift+右クリック: 角の指定を取り消し(もう一度で終了)"), 130, 162, 0xAAAAAA);
        }
    }
}
