package jp.citybuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** クライアントからの配置指示を信用せず、サーバーで必ず検証する */
public final class PlacementValidator {
    private static final Map<UUID, Integer> LAST = new HashMap<>();

    private PlacementValidator() {}

    public static boolean canUse(class_3222 p) {
        CityConfig c = CityBuilderMod.config();
        if (p.method_5687(c.permissionLevel)) return true;
        String name = p.method_7334().getName();
        for (String s : c.allowedPlayers) if (s.equalsIgnoreCase(name)) return true;
        return false;
    }

    public static boolean canUse(class_2168 src) {
        if (src.method_9259(CityBuilderMod.config().permissionLevel)) return true;
        if (src.method_9228() instanceof class_3222 p) return canUse(p);
        return false;
    }

    /** GUI(パケット)経由の配置に対する権限・ゲームモード・連打チェック。問題なければ null */
    public static String checkPlayerRequest(class_3222 p) {
        CityConfig c = CityBuilderMod.config();
        if (!canUse(p)) return "権限がありません";
        if (c.requireCreative && !p.method_7337()) return "クリエイティブモードで使用してください";
        int now = p.method_5682().method_3780();
        Integer last = LAST.get(p.method_5667());
        if (last != null && now - last < c.cooldownTicks) return "操作が早すぎます";
        LAST.put(p.method_5667(), now);
        return null;
    }

    /**
     * 範囲(両端を含む)の検証。player は null 可(コンソール/コマンド)。
     * 問題なければ null、あればエラー文。
     */
    public static String checkBox(class_3218 w, class_3222 player,
                                  int x1, int y1, int z1, int x2, int y2, int z2) {
        CityConfig c = CityBuilderMod.config();
        String dim = w.method_27983().method_29177().toString();
        if (!c.allowedDimensions.isEmpty() && !c.allowedDimensions.contains(dim)) {
            return "このディメンションでは建築できません: " + dim;
        }
        if (y1 < w.method_31607() || y2 >= w.method_31600()) return "高さがワールドの範囲外です";
        long vol = (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
        if (vol > c.maxVolume) return "範囲が大きすぎます";
        if (Math.abs(x1) > 29_999_000 || Math.abs(x2) > 29_999_000 || Math.abs(z1) > 29_999_000 || Math.abs(z2) > 29_999_000) {
            return "座標がワールド境界の外です";
        }
        if (!c.buildAreas.isEmpty()) {
            boolean ok = false;
            for (IntBox b : c.buildAreas) if (b.contains(x1, z1, x2, z2)) { ok = true; break; }
            if (!ok) return "建築可能範囲の外です";
        }
        for (IntBox b : c.protectedAreas) {
            if (b.intersects(x1, z1, x2, z2)) return "保護区域に含まれています";
        }
        if (player != null) {
            double px = player.method_23317(), py = player.method_23318(), pz = player.method_23321();
            double cx = Math.max(x1, Math.min(px, x2 + 1));
            double cy = Math.max(y1, Math.min(py, y2 + 1));
            double cz = Math.max(z1, Math.min(pz, z2 + 1));
            double d = Math.sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy) + (pz - cz) * (pz - cz));
            if (d > c.maxPlaceDistance) return "遠すぎます(最大 " + c.maxPlaceDistance + " ブロック)";
        }
        return null;
    }
}
